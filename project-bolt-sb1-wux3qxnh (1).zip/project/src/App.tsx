import { useEffect, useMemo, useRef, useState } from 'react';
import type { KeyboardEvent } from 'react';
import {
  Activity,
  ArrowUpRight,
  BarChart3,
  Bell,
  Bot,
  BrainCircuit,
  BriefcaseBusiness,
  CalendarDays,
  Check,
  ChevronRight,
  Code2,
  Database,
  FileCode2,
  FileText,
  FolderKanban,
  Globe2,
  Image,
  LayoutDashboard,
  LineChart,
  Menu,
  Mic2,
  MoreHorizontal,
  Network,
  Paperclip,
  Plus,
  Rocket,
  Search,
  Send,
  Settings,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Store,
  TerminalSquare,
  Upload,
  Users,
  Video,
  WandSparkles,
  X,
  Zap,
} from 'lucide-react';
import { AstraLogo } from '@/components/AstraLogo';
import { Markdown } from '@/components/Markdown';
import { generateResponse } from '@/lib/aiEngine';
import { MODELS, getModelName, getStoredModel, setStoredModel } from '@/lib/storage';
import type { Message } from '@/lib/types';

interface NavItem {
  id: string;
  label: string;
  icon: typeof LayoutDashboard;
  accent: string;
}

interface WorkspaceCard {
  id: string;
  title: string;
  description: string;
  icon: typeof LayoutDashboard;
  accent: string;
  stat: string;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'Home', icon: LayoutDashboard, accent: 'cyan' },
  { id: 'chat', label: 'ASTRA Chat', icon: Bot, accent: 'blue' },
  { id: 'image-generator', label: 'Image Generator', icon: Image, accent: 'violet' },
  { id: 'video-generator', label: 'Video Generator', icon: Video, accent: 'rose' },
  { id: 'audio', label: 'Audio / Voice', icon: Mic2, accent: 'pink' },
  { id: 'coding', label: 'Code & Dev', icon: Code2, accent: 'green' },
  { id: 'app-factory', label: 'App Builder', icon: Store, accent: 'indigo' },
  { id: 'website-factory', label: 'Website Builder', icon: Globe2, accent: 'teal' },
  { id: 'agents', label: 'Agents', icon: Users, accent: 'fuchsia' },
  { id: 'research', label: 'Research', icon: Search, accent: 'amber' },
  { id: 'files', label: 'Files & Docs', icon: FileText, accent: 'sky' },
  { id: 'automation', label: 'Automation', icon: Zap, accent: 'blue' },
  { id: 'market', label: 'Trading & Finance', icon: BarChart3, accent: 'emerald' },
  { id: 'affiliate', label: 'Marketing & Affiliate', icon: LineChart, accent: 'orange' },
  { id: 'learning', label: 'Learning & Study', icon: BrainCircuit, accent: 'violet' },
  { id: 'commerce', label: 'Business & Productivity', icon: BriefcaseBusiness, accent: 'rose' },
  { id: 'providers', label: 'AI Models', icon: Network, accent: 'green' },
  { id: 'tools', label: 'Tools & Plugins', icon: WandSparkles, accent: 'violet' },
  { id: 'more', label: 'More', icon: MoreHorizontal, accent: 'sky' },
  { id: 'control', label: 'Control Hub', icon: ShieldCheck, accent: 'fuchsia' },
];

const WORKSPACES: WorkspaceCard[] = [
  { id: 'chat', title: 'Chat', description: 'General AI chat, solutions, ideas and more.', icon: Bot, accent: 'cyan', stat: 'Ready' },
  { id: 'image-generator', title: 'Image Generator', description: 'Create stunning images with AI plans.', icon: Image, accent: 'violet', stat: 'Studio' },
  { id: 'video-generator', title: 'Video Generator', description: 'Turn your ideas into production-ready video plans.', icon: Video, accent: 'rose', stat: 'Studio' },
  { id: 'audio', title: 'Audio / Voice', description: 'Text to speech, voice and sound workflows.', icon: Mic2, accent: 'pink', stat: 'Studio' },
  { id: 'coding', title: 'Code Assistant', description: 'Write, debug, and build software faster.', icon: Code2, accent: 'blue', stat: 'Ready' },
  { id: 'app-factory', title: 'App Builder', description: 'Create mobile and web app blueprints.', icon: Store, accent: 'indigo', stat: 'Builder' },
  { id: 'website-factory', title: 'Website Builder', description: 'Build professional websites with AI guidance.', icon: Globe2, accent: 'teal', stat: 'Builder' },
  { id: 'agents', title: 'Agents', description: 'Multi-agent systems for complex tasks.', icon: Users, accent: 'fuchsia', stat: '32 agents' },
  { id: 'market', title: 'Trading & Finance', description: 'Informational data, analysis and insights.', icon: BarChart3, accent: 'emerald', stat: 'No trading' },
  { id: 'affiliate', title: 'Marketing & Affiliate', description: 'Create content, offers and growth systems.', icon: LineChart, accent: 'orange', stat: 'Foundation' },
  { id: 'learning', title: 'Learning & Study', description: 'Personalized notes, tutor and courses.', icon: BrainCircuit, accent: 'violet', stat: 'Ready' },
  { id: 'commerce', title: 'Business & Productivity', description: 'Plan, organize, automate and grow.', icon: BriefcaseBusiness, accent: 'rose', stat: 'Workspace' },
];

const MARKET_ROWS = [
  { name: 'NIFTY 50', value: '24,728.65', change: '+1.34%', tone: 'text-emerald-300' },
  { name: 'BANKNIFTY', value: '51,892.10', change: '+1.27%', tone: 'text-emerald-300' },
  { name: 'BTC', value: '68,432.50', change: '+2.18%', tone: 'text-emerald-300' },
  { name: 'ETH', value: '3,254.76', change: '+1.96%', tone: 'text-emerald-300' },
];

const QUICK_TOOLS = [
  { label: 'New Project', icon: FolderKanban, action: 'projects' },
  { label: 'Upload File', icon: Upload, action: 'files' },
  { label: 'Create App', icon: Store, action: 'app-factory' },
  { label: 'Deploy', icon: Rocket, action: 'control' },
  { label: 'Research', icon: Search, action: 'research' },
  { label: 'Analytics', icon: BarChart3, action: 'market' },
  { label: 'Calendar', icon: CalendarDays, action: 'affiliate' },
  { label: 'Settings', icon: Settings, action: 'control' },
];

const ACCENT_STYLES: Record<string, { icon: string; border: string; glow: string; pill: string }> = {
  cyan: { icon: 'from-cyan-400 to-blue-600', border: 'border-cyan-400/35', glow: 'hover:shadow-cyan-500/20', pill: 'bg-cyan-400/10 text-cyan-200' },
  blue: { icon: 'from-blue-400 to-indigo-600', border: 'border-blue-400/35', glow: 'hover:shadow-blue-500/20', pill: 'bg-blue-400/10 text-blue-200' },
  indigo: { icon: 'from-indigo-400 to-violet-600', border: 'border-indigo-400/35', glow: 'hover:shadow-indigo-500/20', pill: 'bg-indigo-400/10 text-indigo-200' },
  violet: { icon: 'from-violet-400 to-fuchsia-600', border: 'border-violet-400/35', glow: 'hover:shadow-violet-500/20', pill: 'bg-violet-400/10 text-violet-200' },
  pink: { icon: 'from-pink-400 to-fuchsia-600', border: 'border-pink-400/35', glow: 'hover:shadow-pink-500/20', pill: 'bg-pink-400/10 text-pink-200' },
  rose: { icon: 'from-rose-400 to-pink-600', border: 'border-rose-400/35', glow: 'hover:shadow-rose-500/20', pill: 'bg-rose-400/10 text-rose-200' },
  green: { icon: 'from-emerald-400 to-cyan-600', border: 'border-emerald-400/35', glow: 'hover:shadow-emerald-500/20', pill: 'bg-emerald-400/10 text-emerald-200' },
  amber: { icon: 'from-amber-300 to-orange-600', border: 'border-amber-400/35', glow: 'hover:shadow-amber-500/20', pill: 'bg-amber-400/10 text-amber-200' },
  orange: { icon: 'from-orange-300 to-rose-600', border: 'border-orange-400/35', glow: 'hover:shadow-orange-500/20', pill: 'bg-orange-400/10 text-orange-200' },
  emerald: { icon: 'from-emerald-300 to-teal-600', border: 'border-emerald-400/35', glow: 'hover:shadow-emerald-500/20', pill: 'bg-emerald-400/10 text-emerald-200' },
  teal: { icon: 'from-teal-300 to-cyan-600', border: 'border-teal-400/35', glow: 'hover:shadow-teal-500/20', pill: 'bg-teal-400/10 text-teal-200' },
  sky: { icon: 'from-sky-300 to-blue-600', border: 'border-sky-400/35', glow: 'hover:shadow-sky-500/20', pill: 'bg-sky-400/10 text-sky-200' },
  fuchsia: { icon: 'from-fuchsia-300 to-purple-600', border: 'border-fuchsia-400/35', glow: 'hover:shadow-fuchsia-500/20', pill: 'bg-fuchsia-400/10 text-fuchsia-200' },
};

function IconBox({ icon: Icon, accent, size = 18 }: { icon: typeof LayoutDashboard; accent: string; size?: number }) {
  const style = ACCENT_STYLES[accent] || ACCENT_STYLES.cyan;
  return <div className={`w-9 h-9 shrink-0 rounded-xl bg-gradient-to-br ${style.icon} flex items-center justify-center text-white shadow-lg`}><Icon size={size} /></div>;
}

function App() {
  const [activeWorkspace, setActiveWorkspace] = useState('home');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [commandOpen, setCommandOpen] = useState(false);
  const [toast, setToast] = useState('');
  const [updatePrompt, setUpdatePrompt] = useState('');
  const [updateDraft, setUpdateDraft] = useState('');

  useEffect(() => {
    const onKeyDown = (event: globalThis.KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setCommandOpen((value) => !value);
      }
      if (event.key === 'Escape') {
        setCommandOpen(false);
        setMobileNavOpen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const navigate = (id: string) => {
    setActiveWorkspace(id);
    setMobileNavOpen(false);
    setCommandOpen(false);
  };

  const notify = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(''), 2600);
  };

  const activeNav = NAV_ITEMS.find((item) => item.id === activeWorkspace) || NAV_ITEMS[0];

  return (
    <div className="astra-shell min-h-screen text-slate-100 flex overflow-hidden">
      <Sidebar active={activeWorkspace} isOpen={mobileNavOpen} onNavigate={navigate} onClose={() => setMobileNavOpen(false)} />
      <div className="flex-1 min-w-0 flex flex-col">
        <TopBar onMenu={() => setMobileNavOpen(true)} onCommand={() => setCommandOpen(true)} onNotify={notify} />
        <main className="flex-1 overflow-y-auto">
          <div className="max-w-[1600px] mx-auto p-4 sm:p-6 lg:p-7">
            {activeWorkspace === 'home' ? (
              <CommandCenter onNavigate={navigate} onNotify={notify} />
            ) : activeWorkspace === 'chat' ? (
              <ChatWorkspace onNotify={notify} />
            ) : activeWorkspace === 'providers' ? (
              <ProviderHubView onNotify={notify} />
            ) : activeWorkspace === 'control' ? (
              <ControlHub updatePrompt={updatePrompt} setUpdatePrompt={setUpdatePrompt} updateDraft={updateDraft} setUpdateDraft={setUpdateDraft} onNotify={notify} />
            ) : (
              <WorkspaceView item={activeNav} onNavigate={navigate} onNotify={notify} />
            )}
          </div>
        </main>
      </div>
      {commandOpen && <CommandPalette onClose={() => setCommandOpen(false)} onNavigate={navigate} />}
      {toast && <div className="fixed bottom-5 right-5 z-[70] glass-panel border-cyan-400/35 px-4 py-3 rounded-xl flex items-center gap-2 text-sm shadow-2xl animate-slide-up"><Check size={16} className="text-emerald-300" />{toast}</div>}
    </div>
  );
}

function Sidebar({ active, isOpen, onNavigate, onClose }: { active: string; isOpen: boolean; onNavigate: (id: string) => void; onClose: () => void }) {
  return <>
    {isOpen && <button aria-label="Close navigation" onClick={onClose} className="fixed inset-0 bg-black/70 z-30 lg:hidden" />}
    <aside className={`fixed lg:static z-40 inset-y-0 left-0 w-[260px] shrink-0 bg-[#030817]/95 lg:bg-[#030817]/75 border-r border-cyan-400/10 backdrop-blur-2xl flex flex-col transition-transform duration-300 ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
      <div className="h-[76px] px-5 flex items-center justify-between border-b border-white/5">
        <div className="flex items-center gap-2.5"><AstraLogo size={45} /><div><div className="text-xl font-black tracking-[0.25em] text-gradient leading-none">ASTRA</div><div className="text-[9px] tracking-[0.3em] text-cyan-100/55 mt-1">AI OPERATING SYSTEM</div></div></div>
        <button onClick={onClose} className="lg:hidden text-slate-400"><X size={18} /></button>
      </div>
      <div className="px-3 pt-4 pb-2"><button onClick={() => onNavigate('chat')} className="w-full rounded-xl px-3 py-3 flex items-center gap-3 bg-gradient-to-r from-cyan-400/15 to-fuchsia-500/15 border border-cyan-400/30 text-sm font-semibold hover:border-cyan-300/60 transition-all"><Plus size={17} className="text-cyan-300" />New command<span className="ml-auto text-[10px] text-slate-500">⌘ K</span></button></div>
      <nav className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
        <div className="px-3 pt-2 pb-2 text-[10px] uppercase tracking-[0.2em] text-slate-600">Workspace</div>
        {NAV_ITEMS.map((item) => { const Icon = item.icon; const selected = active === item.id; return <button key={item.id} onClick={() => onNavigate(item.id)} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${selected ? 'bg-gradient-to-r from-cyan-400/20 to-indigo-500/20 text-white border border-cyan-400/25 shadow-[0_0_22px_rgba(34,211,238,0.08)]' : 'text-slate-400 hover:text-slate-100 hover:bg-white/5'}`}><Icon size={17} className={selected ? 'text-cyan-300' : 'text-slate-500'} /><span className="truncate">{item.label}</span>{selected && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-cyan-300 shadow-[0_0_8px_#67e8f9]" />}</button>; })}
        <div className="px-3 pt-5 pb-2 text-[10px] uppercase tracking-[0.2em] text-slate-600">System</div>
        {['integrations', 'memory', 'settings'].map((id) => { const item = id === 'integrations' ? { label: 'Integrations', icon: Network } : id === 'memory' ? { label: 'Memory', icon: BrainCircuit } : { label: 'Settings', icon: Settings }; const Icon = item.icon; return <button key={id} onClick={() => onNavigate('control')} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-slate-400 hover:text-slate-100 hover:bg-white/5 transition-all"><Icon size={17} className="text-slate-500" />{item.label}</button>; })}
      </nav>
      <div className="p-3 border-t border-white/5 space-y-3"><div className="glass-panel rounded-xl p-3"><div className="flex items-center gap-2 mb-2"><div className="w-7 h-7 rounded-lg bg-gradient-to-br from-cyan-500 to-indigo-600 flex items-center justify-center"><AstraLogo size={22} /></div><div><p className="text-xs font-semibold">Your AI Workspace</p><p className="text-[10px] text-slate-500">Foundation plan</p></div></div><div className="h-1 rounded-full bg-white/10 overflow-hidden"><div className="h-full w-1/3 bg-gradient-to-r from-cyan-400 to-violet-500 rounded-full" /></div><button onClick={() => onNavigate('control')} className="w-full mt-3 text-[11px] py-1.5 rounded-lg border border-cyan-400/25 text-cyan-200 hover:bg-cyan-400/10">Open Control Hub</button></div><div className="relative overflow-hidden rounded-xl border border-fuchsia-400/25 p-3 bg-gradient-to-br from-fuchsia-500/10 to-cyan-500/10"><div className="absolute -right-5 -bottom-8 w-20 h-20 rounded-full bg-fuchsia-500/20 blur-2xl" /><p className="text-xs font-bold text-white">Build your own AI apps</p><p className="text-[10px] text-slate-400 mt-1">Turn an idea into a safe plan.</p><button onClick={() => onNavigate('app-factory')} className="mt-2 text-[11px] text-cyan-300 flex items-center gap-1">Start building <ArrowUpRight size={12} /></button></div></div>
    </aside>
  </>;
}

function TopBar({ onMenu, onCommand, onNotify }: { onMenu: () => void; onCommand: () => void; onNotify: (message: string) => void }) {
  return <header className="h-[76px] shrink-0 border-b border-cyan-400/10 bg-[#050b1c]/70 backdrop-blur-xl flex items-center gap-4 px-4 sm:px-6"><button onClick={onMenu} className="lg:hidden text-slate-300"><Menu size={22} /></button><div className="hidden xl:block text-sm text-slate-500">One assistant <span className="mx-2 text-cyan-400">·</span> Infinite possibilities</div><button onClick={onCommand} className="ml-auto w-full max-w-[430px] rounded-full border border-indigo-400/35 bg-black/20 px-4 py-2.5 text-left flex items-center gap-3 text-sm text-slate-400 hover:border-cyan-400/45 transition-all"><Search size={17} /><span>Search anything...</span><kbd className="ml-auto text-[10px] px-2 py-1 rounded-md border border-white/10 text-slate-500">⌘ K</kbd></button><button onClick={() => onNotify('No new notifications')} className="relative p-2 text-slate-400 hover:text-white"><Bell size={18} /><span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-rose-400" /></button><div className="hidden sm:flex items-center gap-2 pl-2 border-l border-white/10"><div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-400 to-indigo-600 flex items-center justify-center text-xs font-bold">JG</div><div className="hidden xl:block"><p className="text-xs font-semibold text-slate-200">Owner</p><p className="text-[10px] text-emerald-300 flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />Online</p></div></div></header>;
}

function CommandCenter({ onNavigate, onNotify }: { onNavigate: (id: string) => void; onNotify: (message: string) => void }) {
  return <div className="space-y-5 animate-fade-in"><div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_285px] gap-4 items-start"><div className="space-y-5"><HeroBanner onNavigate={onNavigate} onNotify={onNotify} /><section className="flex items-center justify-between"><div><p className="text-[11px] uppercase tracking-[0.22em] text-cyan-300/70">Your operating system</p><h2 className="text-xl font-bold mt-1">Main features</h2></div><button onClick={() => onNavigate('control')} className="text-xs text-cyan-300 flex items-center gap-1 hover:text-white">View all <ChevronRight size={14} /></button></section><section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">{WORKSPACES.map((item) => <WorkspaceTile key={item.id} item={item} onClick={() => onNavigate(item.id)} />)}</section><BuildBanner onClick={() => onNavigate('app-factory')} /><LatestTools onNavigate={onNavigate} /><LatestModelsTools onNavigate={onNavigate} /></div><RightRail onNavigate={onNavigate} /></div></div>;
}

function HeroBanner({ onNavigate, onNotify }: { onNavigate: (id: string) => void; onNotify: (message: string) => void }) { return <section className="hero-panel relative overflow-hidden rounded-2xl min-h-[304px] border border-cyan-400/30"><div className="absolute inset-0 hero-stars" /><div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-cyan-500/15 to-transparent" /><div className="absolute -top-44 left-[42%] w-[420px] h-[420px] rounded-full border border-cyan-300/30 shadow-[0_0_110px_rgba(34,211,238,0.3)]" /><div className="absolute -top-20 left-[45%] w-[300px] h-[300px] rounded-full border border-fuchsia-400/45 rotate-45" /><div className="absolute left-[47%] top-12 w-40 h-40 rounded-full bg-cyan-400/20 blur-3xl" /><div className="absolute right-12 top-12 text-right hidden md:block"><p className="text-sm text-fuchsia-200/90">Dream it. Plan it.</p><p className="text-xs text-cyan-200/80 mt-1">ASTRA builds it.</p><div className="w-16 h-px bg-gradient-to-r from-fuchsia-400 to-cyan-400 ml-auto mt-4" /></div><div className="relative p-6 sm:p-8 lg:p-9 flex flex-col justify-between min-h-[304px]"><div className="max-w-[430px]"><p className="text-sm text-cyan-200/85 mb-3">Hello, Owner</p><h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white">Your AI assistant<span className="text-cyan-300">.</span></h1><p className="mt-2 text-sm text-slate-300/85 leading-6">Your creative partner, productivity engine and personal operating system.</p></div><div className="flex flex-col sm:flex-row gap-3 mt-8 max-w-2xl"><button onClick={() => onNavigate('chat')} className="flex-1 flex items-center gap-3 rounded-full border border-cyan-300/70 bg-black/35 px-4 py-3.5 text-left text-sm text-slate-300 hover:bg-cyan-400/10 transition-all shadow-[0_0_30px_rgba(34,211,238,0.15)]"><Plus size={19} className="text-cyan-300" /><span>Ask ASTRA anything...</span><Mic2 size={17} className="ml-auto text-slate-500" /><Send size={17} className="text-cyan-300" /></button><div className="flex gap-2"><button onClick={() => onNavigate('control')} className="rounded-full border border-white/15 bg-white/5 px-4 py-3 text-xs hover:bg-white/10">Plan workflow</button><button onClick={() => onNotify('No provider connected. Open AI Models to choose one.')} className="rounded-full border border-fuchsia-400/30 bg-fuchsia-400/10 px-4 py-3 text-xs text-fuchsia-100 hover:bg-fuchsia-400/20">Connect AI</button></div></div></div><div className="absolute right-[37%] top-8 hidden sm:block"><AstraLogo size={130} /></div><div className="absolute left-1/2 -translate-x-1/2 bottom-[-2px] hidden md:flex items-center gap-2 translate-y-full pt-3">{[['Think', BrainCircuit, 'chat'], ['Search', Search, 'research'], ['Code', Code2, 'coding'], ['Tools', WandSparkles, 'tools'], ['Image', Image, 'image-generator'], ['Video', Video, 'video-generator'], ['Voice', Mic2, 'audio'], ['More', MoreHorizontal, 'control']].map(([label, Icon, id]) => <button key={String(label)} onClick={() => onNavigate(String(id))} className="flex items-center gap-1.5 rounded-lg border border-indigo-400/30 bg-[#080d20]/90 px-3 py-1.5 text-[10px] text-slate-300 hover:border-cyan-400/50 hover:text-white transition-all"><Icon size={12} className="text-cyan-200" />{String(label)}</button>)}</div></section>; }

function WorkspaceTile({ item, onClick }: { item: WorkspaceCard; onClick: () => void }) { const style = ACCENT_STYLES[item.accent]; return <button onClick={onClick} className={`glass-panel group p-4 text-left rounded-xl border ${style.border} ${style.glow} hover:-translate-y-0.5 transition-all`}><div className="flex items-start gap-3"><IconBox icon={item.icon} accent={item.accent} /><div className="min-w-0"><div className="flex items-center gap-2"><h3 className="font-semibold text-sm truncate">{item.title}</h3><span className={`text-[9px] px-1.5 py-0.5 rounded-full ${style.pill}`}>{item.stat}</span></div><p className="text-xs leading-5 text-slate-400 mt-1 line-clamp-2">{item.description}</p></div></div><div className="mt-4 flex justify-end text-slate-500 group-hover:text-cyan-300 transition-colors"><ArrowUpRight size={15} /></div></button>; }

function BuildBanner({ onClick }: { onClick: () => void }) { return <section className="relative overflow-hidden rounded-xl border border-fuchsia-400/30 bg-gradient-to-br from-indigo-950/80 via-[#0b1235] to-fuchsia-950/50 p-5 sm:p-6"><div className="absolute -right-10 -top-16 h-64 w-64 rounded-full border border-fuchsia-400/20 shadow-[0_0_90px_rgba(217,70,239,0.22)]" /><div className="absolute right-24 bottom-0 w-52 h-20 bg-cyan-400/20 blur-3xl" /><div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-5"><div className="flex gap-3"><IconBox icon={Sparkles} accent="violet" size={20} /><div><p className="text-xs uppercase tracking-[0.18em] text-fuchsia-200/80">ASTRA Forge</p><h3 className="text-xl font-bold mt-1">Create your own AI apps</h3><p className="text-sm text-slate-400 mt-1 max-w-md">Describe an idea. ASTRA turns it into a safe plan with checkpoints before anything changes.</p><button onClick={onClick} className="mt-4 rounded-full bg-gradient-to-r from-cyan-400 to-indigo-500 px-4 py-2 text-xs font-bold text-slate-950 hover:scale-105 transition-transform">Start building <ArrowUpRight size={14} className="inline ml-1" /></button></div></div><div className="hidden sm:flex items-center gap-2 text-xs text-slate-300"><Check size={15} className="text-emerald-300" /> Approval-first changes</div></div></section>; }

function LatestTools({ onNavigate }: { onNavigate: (id: string) => void }) { return <section className="glass-panel rounded-xl p-5"><div className="flex items-center justify-between mb-4"><div><p className="text-[10px] uppercase tracking-[0.2em] text-slate-500">Connected surface</p><h3 className="font-bold mt-1">Quick tools</h3></div><Zap size={17} className="text-amber-300" /></div><div className="grid grid-cols-4 gap-2">{QUICK_TOOLS.map((tool) => <button key={tool.label} onClick={() => onNavigate(tool.action)} className="rounded-lg border border-white/10 bg-white/[0.03] p-2.5 flex flex-col items-center gap-2 text-center hover:border-cyan-400/30 hover:bg-cyan-400/5 transition-all"><tool.icon size={17} className="text-cyan-200" /><span className="text-[10px] text-slate-400 leading-4">{tool.label}</span></button>)}</div></section>; }

function LatestModelsTools({ onNavigate }: { onNavigate: (id: string) => void }) { const tools = [['GPT-4o', 'OpenAI', Bot, 'providers'], ['Claude 3.5', 'Anthropic', BrainCircuit, 'providers'], ['Gemini 1.5', 'Google', Sparkles, 'providers'], ['Flux', 'Image Gen', Image, 'image-generator'], ['Runway', 'Video Gen', Video, 'video-generator'], ['ElevenLabs', 'Voice', Mic2, 'audio'], ['TradingView', 'Market Data', BarChart3, 'market'], ['Midjourney', 'Image', Image, 'image-generator'], ['GitHub', 'Code', Code2, 'coding']]; return <section className="glass-panel rounded-xl p-5"><div className="flex items-center justify-between mb-4"><div><p className="text-[10px] uppercase tracking-[0.2em] text-slate-500">Your connected surface</p><h3 className="font-bold mt-1">Latest AI Models & Tools</h3></div><button onClick={() => onNavigate('providers')} className="text-xs text-cyan-300 flex items-center gap-1">View all <ChevronRight size={13} /></button></div><div className="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-9 gap-2">{tools.map(([name, provider, Icon, target]) => <button key={String(name)} onClick={() => onNavigate(String(target))} className="rounded-lg border border-white/10 bg-white/[0.03] p-2.5 text-left hover:border-cyan-400/30 transition-all"><div className="w-7 h-7 rounded-lg bg-gradient-to-br from-slate-700 to-slate-900 border border-white/10 flex items-center justify-center mb-2"><Icon size={14} className="text-cyan-200" /></div><p className="text-[11px] font-medium text-slate-200 truncate">{String(name)}</p><p className="text-[9px] text-slate-500 truncate mt-0.5">{String(provider)}</p></button>)}</div></section>; }

function WorkspaceView({ item, onNavigate, onNotify }: { item: NavItem; onNavigate: (id: string) => void; onNotify: (message: string) => void }) { const Icon = item.icon; const style = ACCENT_STYLES[item.accent]; const isAffiliate = item.id === 'affiliate'; const isFactory = item.id.includes('factory'); return <div className="space-y-6 animate-fade-in"><div className="flex flex-col md:flex-row md:items-end justify-between gap-4"><div><div className="flex items-center gap-3"><IconBox icon={Icon} accent={item.accent} size={21} /><div><p className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Workspace</p><h1 className="text-2xl sm:text-3xl font-bold mt-1">{item.label}</h1></div></div><p className="text-sm text-slate-400 mt-3 max-w-2xl">{isAffiliate ? 'A dedicated growth operating system for research, offers, content, creative, landing pages, tracking and optimization.' : isFactory ? 'A safe creation pipeline that turns a plain-language idea into a structured build plan without pretending an external provider completed the work.' : 'A focused ASTRA workspace with persistent-ready foundations, clear system status and approval-first actions.'}</p></div><button onClick={() => onNavigate('chat')} className={`rounded-lg border ${style.border} px-4 py-2.5 text-sm text-slate-200 hover:bg-white/5 flex items-center gap-2`}><Bot size={16} className="text-cyan-300" /> Ask ASTRA</button></div><div className="grid grid-cols-1 md:grid-cols-3 gap-3"><StatusCard label="Workspace status" value="Foundation ready" icon={Activity} accent={item.accent} /><StatusCard label="Connected data" value="Not connected" icon={Database} accent="amber" /><StatusCard label="Safe actions" value="Approval required" icon={ShieldCheck} accent="emerald" /></div><div className="grid grid-cols-1 xl:grid-cols-[1.3fr_0.7fr] gap-4"><section className="glass-panel rounded-2xl p-5 sm:p-7"><div className="flex items-center justify-between"><div><p className="text-[10px] uppercase tracking-[0.2em] text-slate-500">Next action</p><h2 className="text-xl font-bold mt-1">Start with a clear brief</h2></div><Sparkles size={20} className="text-cyan-300" /></div><div className="mt-6 rounded-xl border border-dashed border-cyan-400/25 bg-cyan-400/[0.03] p-6 text-center"><Icon size={32} className="mx-auto text-cyan-300/80 mb-3" /><p className="text-sm text-slate-300">No live provider or connector is configured for this workspace.</p><p className="text-xs text-slate-500 mt-2">ASTRA will show the plan and required setup instead of claiming a result.</p><button onClick={() => onNotify('Brief saved as a local workspace draft.')} className="mt-5 rounded-lg bg-cyan-400/15 border border-cyan-300/30 text-cyan-100 px-4 py-2 text-xs hover:bg-cyan-400/25">Create workspace brief</button></div></section><section className="glass-panel rounded-2xl p-5"><h3 className="font-semibold">Suggested modules</h3><div className="mt-4 space-y-2">{(isAffiliate ? ['Product research', 'Offer tracker', 'Content planner', 'UTM architecture', 'Performance dashboard'] : isFactory ? ['Idea brief', 'Architecture plan', 'Provider check', 'Approval checkpoint', 'Validation log'] : ['Overview', 'Workspace files', 'Tasks & automation', 'Activity log', 'Settings']).map((module) => <button key={module} onClick={() => onNotify(`${module} is ready to define.`)} className="w-full flex items-center gap-3 rounded-lg px-3 py-2.5 bg-white/[0.03] border border-white/5 hover:border-cyan-400/25 text-left text-sm text-slate-300"><ChevronRight size={14} className="text-cyan-300" />{module}</button>)}</div></section></div></div>; }

function StatusCard({ label, value, icon: Icon, accent }: { label: string; value: string; icon: typeof Activity; accent: string }) { return <div className="glass-panel rounded-xl p-4 flex items-center gap-3"><IconBox icon={Icon} accent={accent} size={17} /><div><p className="text-[10px] uppercase tracking-[0.12em] text-slate-500">{label}</p><p className="text-sm font-semibold mt-1 text-slate-200">{value}</p></div></div>; }

function ControlHub({ updatePrompt, setUpdatePrompt, updateDraft, setUpdateDraft, onNotify }: { updatePrompt: string; setUpdatePrompt: (value: string) => void; updateDraft: string; setUpdateDraft: (value: string) => void; onNotify: (message: string) => void }) { const [approved, setApproved] = useState(false); const [activeTab, setActiveTab] = useState('overview'); const tabs = ['overview', 'developer chat', 'upgrade center', 'versions', 'providers']; const submit = () => { if (!updatePrompt.trim()) return; setUpdateDraft(updatePrompt.trim()); setUpdatePrompt(''); setApproved(false); }; return <div className="space-y-6 animate-fade-in"><div className="flex flex-col md:flex-row md:items-end justify-between gap-4"><div><div className="flex items-center gap-3"><IconBox icon={ShieldCheck} accent="fuchsia" size={21} /><div><p className="text-[11px] uppercase tracking-[0.2em] text-fuchsia-200/70">Administration & evolution</p><h1 className="text-2xl sm:text-3xl font-bold mt-1">Control Hub</h1></div></div><p className="text-sm text-slate-400 mt-3 max-w-2xl">ASTRA's permanent development department. Every future change is inspected, planned, approved, validated and recorded.</p></div><div className="flex items-center gap-2 rounded-full border border-emerald-400/25 bg-emerald-400/10 px-3 py-2 text-xs text-emerald-200"><span className="w-1.5 h-1.5 rounded-full bg-emerald-300" /> Safe mode active</div></div><div className="flex gap-1 overflow-x-auto border-b border-white/10">{tabs.map((tab) => <button key={tab} onClick={() => setActiveTab(tab)} className={`whitespace-nowrap px-4 py-3 text-xs capitalize border-b-2 transition-all ${activeTab === tab ? 'text-cyan-200 border-cyan-300' : 'text-slate-500 border-transparent hover:text-slate-200'}`}>{tab}</button>)}</div>{activeTab === 'developer chat' ? <DeveloperChat updateDraft={updateDraft} setUpdatePrompt={setUpdatePrompt} onSubmit={submit} approved={approved} setApproved={setApproved} onNotify={onNotify} /> : <div className="grid grid-cols-1 lg:grid-cols-3 gap-4"><div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-3">{[['AI Provider Hub', Network, '0 connected'], ['Agent Registry', Users, '32 specialists'], ['Tool Registry', TerminalSquare, 'Approval-first'], ['Project Health', Activity, 'All systems nominal'], ['Update Center', Zap, '4 opportunities'], ['Version Timeline', GitBranchIcon, 'Checkpoint ready']].map(([title, Icon, value]) => <button key={String(title)} onClick={() => setActiveTab(String(title) === 'Update Center' ? 'upgrade center' : 'overview')} className="glass-panel rounded-xl p-5 text-left hover:border-cyan-400/30 transition-all"><div className="flex items-center justify-between"><IconBox icon={Icon as typeof Activity} accent="fuchsia" /><ChevronRight size={15} className="text-slate-600" /></div><h3 className="font-semibold mt-4">{String(title)}</h3><p className="text-xs text-slate-500 mt-1">{String(value)}</p></button>)}</div><section className="glass-panel rounded-xl p-5"><p className="text-[10px] uppercase tracking-[0.2em] text-cyan-300/70">Permanent developer chat</p><h2 className="text-xl font-bold mt-2">Teach ASTRA what to build next</h2><p className="text-sm text-slate-400 mt-3 leading-6">Give ASTRA a small instruction. It will turn it into an inspectable change proposal before applying anything.</p><button onClick={() => setActiveTab('developer chat')} className="mt-6 w-full rounded-lg bg-gradient-to-r from-cyan-400 to-indigo-500 text-slate-950 font-semibold text-sm py-3 hover:brightness-110">Open developer chat</button></section></div>}{activeTab === 'upgrade center' && <UpgradeCenter onNotify={onNotify} />}{activeTab === 'versions' && <VersionTimeline />}{activeTab === 'providers' && <ProviderHealth />}</div>; }

function DeveloperChat({ updateDraft, setUpdatePrompt, onSubmit, approved, setApproved, onNotify }: { updateDraft: string; setUpdatePrompt: (value: string) => void; onSubmit: () => void; approved: boolean; setApproved: (value: boolean) => void; onNotify: (message: string) => void }) { return <div className="grid grid-cols-1 xl:grid-cols-[0.85fr_1.15fr] gap-4"><section className="glass-panel rounded-2xl p-5"><div className="flex items-center gap-3"><AstraLogo size={36} /><div><h2 className="font-bold">ASTRA Developer</h2><p className="text-xs text-slate-500">Control conversation · approval-first</p></div></div><div className="mt-6 rounded-xl bg-white/[0.03] border border-white/10 p-4 text-sm text-slate-300 leading-6"><p>Tell me what you want to improve, add, repair or create. I will never silently overwrite important work.</p><p className="mt-3 text-cyan-200/80">Try: “Add a new AI provider” or “Create a campaign analytics workspace.”</p></div><textarea value={updateDraft ? '' : undefined} onChange={(event) => setUpdatePrompt(event.target.value)} placeholder="Describe the change you want ASTRA to make..." className="mt-4 w-full min-h-32 rounded-xl bg-[#030817] border border-indigo-400/20 p-4 text-sm text-slate-200 placeholder:text-slate-600 outline-none focus:border-cyan-400/45" /><button onClick={onSubmit} className="mt-3 w-full rounded-xl bg-gradient-to-r from-cyan-400 to-indigo-500 py-3 text-sm font-bold text-slate-950 hover:brightness-110">Inspect request</button></section><section className="glass-panel rounded-2xl p-5"><div className="flex items-center justify-between"><div><p className="text-[10px] uppercase tracking-[0.2em] text-slate-500">Change proposal</p><h2 className="text-xl font-bold mt-1">Understand → inspect → apply</h2></div><ShieldCheck size={20} className="text-emerald-300" /></div>{updateDraft ? <div className="mt-5 space-y-3"><div className="rounded-xl border border-cyan-400/25 bg-cyan-400/[0.04] p-4"><p className="text-[10px] uppercase tracking-[0.16em] text-cyan-300">Requested instruction</p><p className="text-sm text-slate-200 mt-2">{updateDraft}</p></div>{['Understand request and affected workspace', 'Inspect existing capabilities and dependencies', 'Prepare a reversible implementation checkpoint', 'Validate before recording the change journal'].map((step, index) => <div key={step} className="flex items-center gap-3 rounded-lg border border-white/10 px-3 py-3"><span className="w-6 h-6 rounded-full bg-indigo-400/15 text-indigo-200 flex items-center justify-center text-xs">{index + 1}</span><span className="text-sm text-slate-300">{step}</span><Check size={15} className="ml-auto text-emerald-300" /></div>)}<label className="flex items-start gap-3 rounded-xl bg-amber-400/10 border border-amber-300/20 p-3 mt-4 cursor-pointer"><input type="checkbox" checked={approved} onChange={(event) => setApproved(event.target.checked)} className="mt-0.5 accent-cyan-400" /><span className="text-xs text-amber-100/80">I understand this is a proposal. Require approval before applying changes.</span></label><button onClick={() => onNotify(approved ? 'Proposal checkpoint created. No files changed.' : 'Approval is required before ASTRA can continue.')} className="mt-3 w-full rounded-lg border border-cyan-400/30 py-2.5 text-sm text-cyan-100 hover:bg-cyan-400/10">Create checkpoint</button></div> : <div className="min-h-72 flex flex-col items-center justify-center text-center text-slate-500"><FileCode2 size={32} className="text-slate-600 mb-3" /><p className="text-sm">Your next instruction will appear here.</p><p className="text-xs mt-1">No changes are applied silently.</p></div>}</section></div>; }

function UpgradeCenter({ onNotify }: { onNotify: (message: string) => void }) { const upgrades = [['Add a live AI provider', 'Provider Hub · Secure secrets', 'Needs connection', 'medium'], ['Expand affiliate analytics', 'Affiliate Studio · Tracking', 'Architecture ready', 'low'], ['Create mobile workspace shell', 'Responsive app shell', 'Ready to plan', 'low'], ['Review dependency health', 'System · Control Hub', 'Inspection needed', 'high']]; return <section className="glass-panel rounded-2xl p-5"><div className="flex items-center justify-between mb-4"><div><p className="text-[10px] uppercase tracking-[0.2em] text-fuchsia-200/70">Continuous improvement</p><h2 className="text-xl font-bold mt-1">Upgrade opportunities</h2></div><button onClick={() => onNotify('Upgrade scan queued for approval.')} className="rounded-lg border border-fuchsia-400/25 px-3 py-2 text-xs text-fuchsia-100">Run scan</button></div><div className="space-y-2">{upgrades.map(([title, affected, status, risk]) => <div key={title} className="flex flex-col sm:flex-row sm:items-center gap-3 rounded-xl border border-white/10 p-4"><div className="w-8 h-8 rounded-lg bg-fuchsia-400/10 flex items-center justify-center"><Zap size={15} className="text-fuchsia-300" /></div><div className="flex-1"><p className="text-sm font-semibold">{title}</p><p className="text-xs text-slate-500 mt-1">{affected} · {status}</p></div><span className={`text-[10px] px-2 py-1 rounded-full ${risk === 'high' ? 'bg-rose-400/10 text-rose-200' : 'bg-emerald-400/10 text-emerald-200'}`}>{risk} risk</span><button onClick={() => onNotify(`${title} added to the approval queue.`)} className="text-xs text-cyan-300 hover:text-white">Review</button></div>)}</div></section>; }

function VersionTimeline() { return <section className="glass-panel rounded-2xl p-5"><p className="text-[10px] uppercase tracking-[0.2em] text-slate-500">Recoverable history</p><h2 className="text-xl font-bold mt-1">Version timeline</h2><div className="mt-5 space-y-4"><div className="flex gap-3"><div className="flex flex-col items-center"><span className="w-3 h-3 rounded-full bg-emerald-300 shadow-[0_0_10px_#6ee7b7]" /><span className="w-px flex-1 bg-white/10" /></div><div className="pb-4"><p className="text-sm font-semibold">Foundation checkpoint</p><p className="text-xs text-slate-500 mt-1">Current · User-owned · Build verified</p></div></div><div className="flex gap-3"><div className="flex flex-col items-center"><span className="w-3 h-3 rounded-full bg-cyan-300" /><span className="w-px flex-1 bg-white/10" /></div><div className="pb-4"><p className="text-sm font-semibold">Command center created</p><p className="text-xs text-slate-500 mt-1">ASTRA · Reversible design change</p></div></div><div className="flex gap-3"><span className="w-3 h-3 rounded-full bg-indigo-300" /><div><p className="text-sm font-semibold">Chat foundation</p><p className="text-xs text-slate-500 mt-1">System · Local mode enabled</p></div></div></div></section>; }

function ProviderHealth() { return <section className="grid grid-cols-1 sm:grid-cols-2 gap-3">{[['Reasoning & text', Bot, 'Not connected'], ['Web research', Globe2, 'Not connected'], ['Image generation', Image, 'Not connected'], ['Audio & voice', Mic2, 'Not connected']].map(([title, Icon, status]) => <div key={String(title)} className="glass-panel rounded-xl p-5"><IconBox icon={Icon as typeof Activity} accent="fuchsia" /><h3 className="font-semibold mt-4">{String(title)}</h3><p className="text-xs text-amber-200/80 mt-1">{String(status)}</p><button className="mt-4 text-xs text-cyan-300">Configure securely</button></div>)}</section>; }

function ChatWorkspace({ onNotify }: { onNotify: (message: string) => void }) { const [messages, setMessages] = useState<Message[]>([]); const [input, setInput] = useState(''); const [typing, setTyping] = useState(false); const [model, setModel] = useState(getStoredModel()); const scrollRef = useRef<HTMLDivElement>(null); useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' }); }, [messages, typing]); const send = () => { const text = input.trim(); if (!text || typing) return; const user: Message = { id: crypto.randomUUID(), role: 'user', content: text, timestamp: Date.now() }; setMessages((items) => [...items, user]); setInput(''); setTyping(true); window.setTimeout(() => { setMessages((items) => [...items, { id: crypto.randomUUID(), role: 'assistant', content: generateResponse(text, items), timestamp: Date.now(), model }]); setTyping(false); }, 650); }; const onKey = (event: KeyboardEvent<HTMLTextAreaElement>) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); send(); } }; return <div className="max-w-4xl mx-auto flex flex-col min-h-[calc(100vh-150px)] animate-fade-in"><div className="flex items-center justify-between mb-5"><div><p className="text-[11px] uppercase tracking-[0.2em] text-cyan-300/70">Conversation workspace</p><h1 className="text-2xl font-bold mt-1">ASTRA Chat</h1></div><select value={model} onChange={(event) => { setModel(event.target.value); setStoredModel(event.target.value); }} className="rounded-lg border border-indigo-400/25 bg-[#080d20] px-3 py-2 text-xs text-slate-200 outline-none">{MODELS.map((option) => <option key={option.id} value={option.id}>{option.name}</option>)}</select></div><div ref={scrollRef} className="flex-1 space-y-5 overflow-y-auto pr-1 pb-5">{messages.length === 0 ? <div className="glass-panel rounded-2xl p-8 text-center mt-12"><AstraLogo size={62} /><h2 className="text-2xl font-bold text-gradient mt-4">What are we building?</h2><p className="text-sm text-slate-400 mt-2">Ask ASTRA to plan, research, write, code or route a request into any workspace.</p><div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-7">{['Plan a website for my idea', 'Research a new market', 'Create an affiliate workflow', 'Help me debug an app'].map((prompt) => <button key={prompt} onClick={() => setInput(prompt)} className="rounded-lg border border-white/10 bg-white/[0.03] p-3 text-left text-xs text-slate-300 hover:border-cyan-400/30">{prompt}</button>)}</div></div> : messages.map((message) => <div key={message.id} className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : ''}`}><div className={`max-w-[85%] rounded-2xl px-4 py-3 ${message.role === 'user' ? 'bg-gradient-to-br from-indigo-600/80 to-fuchsia-600/70' : 'glass-panel'}`}>{message.role === 'assistant' ? <Markdown content={message.content} /> : <p className="text-sm whitespace-pre-wrap">{message.content}</p>}{message.role === 'assistant' && message.model && <p className="text-[10px] text-slate-600 mt-3">{getModelName(message.model)} · local mode</p>}</div></div>)}{typing && <div className="flex gap-3"><AstraLogo size={32} /><div className="glass-panel rounded-2xl px-4 py-4 flex gap-1"><span className="typing-dot w-2 h-2 rounded-full bg-cyan-300" /><span className="typing-dot w-2 h-2 rounded-full bg-indigo-300" style={{ animationDelay: '200ms' }} /><span className="typing-dot w-2 h-2 rounded-full bg-fuchsia-300" style={{ animationDelay: '400ms' }} /></div></div>}</div><div className="glass-panel rounded-2xl p-2 flex items-end gap-2"><button onClick={() => onNotify('File attachments are ready for the Files workspace.')} className="p-3 text-slate-500 hover:text-cyan-300"><Paperclip size={18} /></button><textarea value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={onKey} rows={1} placeholder="Ask ASTRA anything..." className="flex-1 bg-transparent py-3 text-sm text-white placeholder:text-slate-500 outline-none resize-none max-h-36" /><button onClick={send} disabled={!input.trim() || typing} className="p-3 rounded-xl bg-gradient-to-br from-cyan-400 to-indigo-600 text-slate-950 disabled:opacity-30"><Send size={18} /></button></div><p className="text-center text-[10px] text-slate-600 mt-2">Local mode · no provider claims · Enter to send</p></div>; }

function CommandPalette({ onClose, onNavigate }: { onClose: () => void; onNavigate: (id: string) => void }) { const [query, setQuery] = useState(''); const results = useMemo(() => NAV_ITEMS.filter((item) => item.label.toLowerCase().includes(query.toLowerCase())), [query]); return <div className="fixed inset-0 z-[60] bg-black/70 backdrop-blur-sm flex items-start justify-center pt-[12vh] px-4" onClick={onClose}><div className="w-full max-w-xl glass-panel rounded-2xl overflow-hidden shadow-2xl animate-scale-in" onClick={(event) => event.stopPropagation()}><div className="flex items-center gap-3 px-4 border-b border-white/10"><Search size={18} className="text-cyan-300" /><input autoFocus value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Go to a workspace..." className="flex-1 bg-transparent py-4 text-sm outline-none text-white placeholder:text-slate-500" /><button onClick={onClose}><X size={17} className="text-slate-500" /></button></div><div className="p-2 max-h-80 overflow-y-auto">{results.map((item) => <button key={item.id} onClick={() => onNavigate(item.id)} className="w-full flex items-center gap-3 rounded-lg p-3 text-left hover:bg-cyan-400/10"><IconBox icon={item.icon} accent={item.accent} size={15} /><span className="text-sm">{item.label}</span><ArrowUpRight size={14} className="ml-auto text-slate-600" /></button>)}{results.length === 0 && <p className="p-5 text-sm text-center text-slate-500">No workspace found.</p>}</div></div></div>; }

function RightRail({ onNavigate }: { onNavigate: (id: string) => void }) {
  return <aside className="space-y-4 xl:sticky xl:top-4">
    <div className="glass-panel rounded-xl p-4">
      <div className="flex items-center justify-between mb-3"><div className="flex items-center gap-2"><Activity size={15} className="text-cyan-300" /><h3 className="text-sm font-bold">System status</h3></div><span className="flex items-center gap-1.5 text-[10px] text-emerald-300"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />Ready</span></div>
      <div className="space-y-2.5">{['AI Models', 'Database', 'Storage', 'Network'].map((label, i) => <div key={label} className="flex items-center justify-between text-xs"><span className="text-slate-400">{label}</span><span className={`flex items-center gap-1.5 ${i === 0 ? 'text-amber-300' : 'text-emerald-300'}`}><span className={`w-1.5 h-1.5 rounded-full ${i === 0 ? 'bg-amber-400' : 'bg-emerald-400'}`} />{i === 0 ? 'Needs setup' : i === 3 ? 'Online' : 'Connected'}</span></div>)}</div><button onClick={() => onNavigate('providers')} className="mt-3 w-full rounded-lg border border-cyan-400/30 py-2 text-[10px] text-cyan-200 hover:bg-cyan-400/10">View details</button>
    </div>
    <div className="glass-panel rounded-xl p-4">
      <div className="flex items-center justify-between mb-3"><div className="flex items-center gap-2"><BarChart3 size={15} className="text-emerald-300" /><h3 className="text-sm font-bold">Market</h3></div><button onClick={() => onNavigate('market')} className="text-[10px] text-cyan-300">Open</button></div>
      <div className="space-y-2">{MARKET_ROWS.map((row) => <div key={row.name} className="flex items-center justify-between text-xs"><div><p className="text-slate-300 font-medium">{row.name}</p><p className="text-[10px] text-slate-500">{row.value}</p></div><span className={`font-mono text-[11px] ${row.tone}`}>{row.change}</span></div>)}</div>
      <p className="text-[9px] text-slate-600 mt-3 pt-2 border-t border-white/5">Informational only · No trade execution</p>
    </div>
    <div className="glass-panel rounded-xl p-4">
      <div className="flex items-center justify-between mb-3"><div className="flex items-center gap-2"><Zap size={15} className="text-amber-300" /><h3 className="text-sm font-bold">Quick actions</h3></div></div>
      <div className="grid grid-cols-2 gap-2">{[['New chat', 'chat', Bot], ['New app', 'app-factory', Store], ['Research', 'research', Search], ['Settings', 'control', Settings]].map(([label, id, Icon]) => <button key={String(label)} onClick={() => onNavigate(String(id))} className="rounded-lg border border-white/10 bg-white/[0.03] p-2.5 flex flex-col items-center gap-1.5 hover:border-cyan-400/30 transition-all"><Icon size={16} className="text-cyan-200" /><span className="text-[10px] text-slate-400">{String(label)}</span></button>)}</div>
    </div>
    <div className="glass-panel rounded-xl p-4">
      <div className="flex items-center justify-between mb-3"><div className="flex items-center gap-2"><Bell size={15} className="text-fuchsia-300" /><h3 className="text-sm font-bold">Activity</h3></div></div>
      <div className="space-y-2.5">{['Workspace created', 'Checkpoint saved', 'Provider pending'].map((label, i) => <div key={label} className="flex items-center gap-2.5 text-xs"><span className={`w-1.5 h-1.5 rounded-full ${i === 2 ? 'bg-amber-400' : 'bg-cyan-400'}`} /><span className="text-slate-400">{label}</span><span className="ml-auto text-[10px] text-slate-600">{i === 0 ? '2m' : i === 1 ? '28m' : '1h'}</span></div>)}</div>
    </div>
    <div className="glass-panel rounded-xl p-4 bg-gradient-to-br from-cyan-500/5 to-fuchsia-500/5 border-cyan-400/20">
      <div className="flex items-center gap-2 mb-2"><Smartphone size={15} className="text-cyan-300" /><h3 className="text-sm font-bold">Cross-platform</h3></div>
      <div className="flex gap-2">{['Desktop', 'Tablet', 'Mobile'].map((p) => <span key={p} className="text-[10px] px-2 py-1 rounded-full bg-white/5 text-slate-400">{p}</span>)}</div>
    </div>
  </aside>;
}

function ProviderHubView({ onNotify }: { onNotify: (message: string) => void }) {
  const providers = [
    { name: 'OpenAI', capabilities: 'GPT-4o, DALL-E, TTS, Whisper', status: 'not-connected', keyName: 'OPENAI_API_KEY', accent: 'emerald' },
    { name: 'Anthropic', capabilities: 'Claude 3.5 Sonnet, Claude 3 Opus', status: 'not-connected', keyName: 'ANTHROPIC_API_KEY', accent: 'orange' },
    { name: 'Google AI', capabilities: 'Gemini 1.5 Pro, Imagen, TTS', status: 'not-connected', keyName: 'GOOGLE_AI_API_KEY', accent: 'blue' },
    { name: 'Groq', capabilities: 'Llama 3, Mixtral — ultra-fast inference', status: 'not-connected', keyName: 'GROQ_API_KEY', accent: 'amber' },
    { name: 'Together AI', capabilities: 'Open-source models, embeddings', status: 'not-connected', keyName: 'TOGETHER_API_KEY', accent: 'violet' },
    { name: 'Mistral', capabilities: 'Mistral Large, Codestral, Embed', status: 'not-connected', keyName: 'MISTRAL_API_KEY', accent: 'rose' },
    { name: 'Stability AI', capabilities: 'Stable Diffusion 3, image gen', status: 'not-connected', keyName: 'STABILITY_API_KEY', accent: 'pink' },
    { name: 'ElevenLabs', capabilities: 'Voice synthesis, voice cloning', status: 'not-connected', keyName: 'ELEVENLABS_API_KEY', accent: 'teal' },
    { name: 'Runway', capabilities: 'Video generation, Gen-3', status: 'not-connected', keyName: 'RUNWAY_API_KEY', accent: 'indigo' },
    { name: 'Replicate', capabilities: 'Image, video, audio models', status: 'not-connected', keyName: 'REPLICATE_API_KEY', accent: 'sky' },
    { name: 'Cohere', capabilities: 'Command R+, embeddings, rerank', status: 'not-connected', keyName: 'COHERE_API_KEY', accent: 'green' },
    { name: 'Perplexity', capabilities: 'Online LLMs, web research', status: 'not-connected', keyName: 'PERPLEXITY_API_KEY', accent: 'cyan' },
    { name: 'Tavily', capabilities: 'Search API for research agents', status: 'not-connected', keyName: 'TAVILY_API_KEY', accent: 'teal' },
    { name: 'GitHub', capabilities: 'Repositories, issues, code workflows', status: 'not-connected', keyName: 'GITHUB_TOKEN', accent: 'sky' },
    { name: 'TradingView', capabilities: 'Market charts and watchlists', status: 'not-connected', keyName: 'TRADINGVIEW_API_KEY', accent: 'green' },
    { name: 'Alpha Vantage', capabilities: 'Stocks, forex and market data', status: 'not-connected', keyName: 'ALPHA_VANTAGE_API_KEY', accent: 'emerald' },
    { name: 'Supabase', capabilities: 'Database, auth, storage and edge functions', status: 'connected', keyName: 'SUPABASE_URL + SUPABASE_ANON_KEY', accent: 'green' },
  ];
  return <div className="space-y-6 animate-fade-in">
    <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
      <div><div className="flex items-center gap-3"><IconBox icon={Network} accent="green" size={21} /><div><p className="text-[11px] uppercase tracking-[0.2em] text-slate-500">Provider Hub</p><h1 className="text-2xl sm:text-3xl font-bold mt-1">AI Models</h1></div></div><p className="text-sm text-slate-400 mt-3 max-w-2xl">Connect AI providers to unlock real generation capabilities. Each provider needs its own API key, stored securely server-side. ASTRA never fakes a connection.</p></div>
      <div className="flex items-center gap-2 rounded-full border border-amber-400/25 bg-amber-400/10 px-3 py-2 text-xs text-amber-200"><span className="w-1.5 h-1.5 rounded-full bg-amber-400" /> 1 of 17 connected</div>
    </div>
    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
      <div className="glass-panel rounded-xl p-4 flex items-center gap-3"><IconBox icon={Bot} accent="blue" size={17} /><div><p className="text-[10px] uppercase tracking-[0.12em] text-slate-500">Text & reasoning</p><p className="text-sm font-semibold mt-1">6 providers</p></div></div>
      <div className="glass-panel rounded-xl p-4 flex items-center gap-3"><IconBox icon={Image} accent="violet" size={17} /><div><p className="text-[10px] uppercase tracking-[0.12em] text-slate-500">Image & video</p><p className="text-sm font-semibold mt-1">4 providers</p></div></div>
      <div className="glass-panel rounded-xl p-4 flex items-center gap-3"><IconBox icon={Mic2} accent="pink" size={17} /><div><p className="text-[10px] uppercase tracking-[0.12em] text-slate-500">Audio & voice</p><p className="text-sm font-semibold mt-1">3 providers</p></div></div>
    </div>
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3">
      {providers.map((p) => <ProviderCard key={p.name} provider={p} onNotify={onNotify} />)}
    </div>
    <div className="glass-panel rounded-xl p-5 border-amber-400/20">
      <div className="flex items-start gap-3"><ShieldCheck size={20} className="text-amber-300 mt-0.5" /><div><h3 className="font-semibold text-sm">How API keys work in ASTRA</h3><p className="text-xs text-slate-400 mt-2 leading-5">Each provider needs its own API key. Keys are stored securely as environment variables on the server — never exposed in the browser. Click "Connect" on any provider above to see the exact key name you need and where to get it. ASTRA will never pretend a provider is connected when it isn't.</p></div></div>
    </div>
  </div>;
}

function ProviderCard({ provider, onNotify }: { provider: { name: string; capabilities: string; status: string; keyName: string; accent: string }; onNotify: (message: string) => void }) {
  const style = ACCENT_STYLES[provider.accent] || ACCENT_STYLES.cyan;
  const connected = provider.status === 'connected';
  return <div className={`glass-panel rounded-xl p-5 border ${style.border} hover:-translate-y-0.5 transition-all`}>
    <div className="flex items-center justify-between mb-3"><div className="flex items-center gap-2.5"><div className={`w-9 h-9 rounded-xl bg-gradient-to-br ${style.icon} flex items-center justify-center text-white text-xs font-bold`}>{provider.name.slice(0, 2).toUpperCase()}</div><div><h3 className="font-semibold text-sm">{provider.name}</h3><span className={`text-[9px] px-1.5 py-0.5 rounded-full ${connected ? 'bg-emerald-400/15 text-emerald-200' : style.pill}`}>{connected ? 'Connected' : 'Not connected'}</span></div></div>{connected && <Check size={16} className="text-emerald-300" />}</div>
    <p className="text-xs text-slate-400 leading-5 mb-3">{provider.capabilities}</p>
    <div className="rounded-lg bg-black/30 border border-white/5 p-2.5 mb-3"><p className="text-[10px] text-slate-500 mb-1">{connected ? 'Active keys' : 'Required key'}</p><p className="text-xs font-mono text-cyan-200">{provider.keyName}</p></div>
    <button onClick={() => onNotify(connected ? `${provider.name} is already connected and working.` : `${provider.name} setup: add ${provider.keyName} to your environment variables, then ASTRA will detect it automatically.`)} className={`w-full rounded-lg py-2.5 text-xs transition-all flex items-center justify-center gap-2 ${connected ? 'bg-emerald-400/10 border border-emerald-400/25 text-emerald-200' : 'bg-gradient-to-r from-cyan-400/15 to-indigo-500/15 border border-cyan-400/25 text-cyan-100 hover:bg-cyan-400/20'}`}><ShieldCheck size={14} /> {connected ? 'Manage' : 'Connect securely'}</button>
  </div>;
}

function GitBranchIcon(props: { size?: number }) { return <GitBranchPlaceholder {...props} />; }
function GitBranchPlaceholder({ size = 18 }: { size?: number }) { return <Activity size={size} />; }

export default App;
