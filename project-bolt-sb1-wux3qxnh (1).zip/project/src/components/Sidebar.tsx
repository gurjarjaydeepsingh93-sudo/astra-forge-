import { useState, useMemo } from 'react';
import { Plus, Search, MessageSquare, Trash2, X } from 'lucide-react';
import { AstraLogo } from './AstraLogo';
import type { Conversation } from '@/lib/types';

interface SidebarProps {
  conversations: Conversation[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

function formatRelative(ts: number): string {
  const diff = Date.now() - ts;
  const mins = Math.floor(diff / 60000);
  const hours = Math.floor(mins / 60);
  const days = Math.floor(hours / 24);
  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (mins > 0) return `${mins}m ago`;
  return 'just now';
}

export function Sidebar({
  conversations,
  activeId,
  onSelect,
  onNew,
  onDelete,
  isOpen,
  onClose,
}: SidebarProps) {
  const [search, setSearch] = useState('');

  const sorted = useMemo(
    () => [...conversations].sort((a, b) => b.updatedAt - a.updatedAt),
    [conversations]
  );

  const filtered = useMemo(() => {
    if (!search.trim()) return sorted;
    const q = search.toLowerCase();
    return sorted.filter(
      (c) =>
        c.title.toLowerCase().includes(q) ||
        c.messages.some((m) => m.content.toLowerCase().includes(q))
    );
  }, [sorted, search]);

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-30 lg:hidden animate-fade-in"
          onClick={onClose}
        />
      )}

      <aside
        className={`
          fixed lg:static inset-y-0 left-0 z-40
          w-[280px] flex flex-col
          glass-dark border-r border-indigo-500/15
          transition-transform duration-300
          ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        {/* Header */}
        <div className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <AstraLogo size={32} />
            <div>
              <h1 className="text-base font-bold text-gradient leading-tight">ASTRA</h1>
              <p className="text-[10px] text-slate-500 leading-tight">AI Assistant</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="lg:hidden text-slate-400 hover:text-slate-200 p-1"
          >
            <X size={18} />
          </button>
        </div>

        {/* New chat */}
        <div className="px-3 pb-3">
          <button
            onClick={onNew}
            className="w-full flex items-center gap-2.5 rounded-xl px-4 py-3 text-sm font-medium
              bg-gradient-to-r from-cyan-500/20 to-indigo-500/20 border border-cyan-400/20
              text-slate-200 hover:border-cyan-400/40 hover:from-cyan-500/30 hover:to-indigo-500/30
              transition-all active:scale-[0.98]"
          >
            <Plus size={18} className="text-cyan-400" />
            New Chat
          </button>
        </div>

        {/* Search */}
        <div className="px-3 pb-2">
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search chats..."
              className="w-full pl-9 pr-3 py-2 rounded-lg text-sm bg-white/5 text-slate-200
                placeholder:text-slate-500 outline-none border border-transparent
                focus:border-indigo-500/30 transition-all"
            />
          </div>
        </div>

        {/* Conversation list */}
        <div className="flex-1 overflow-y-auto px-2 pb-4">
          {filtered.length === 0 ? (
            <div className="text-center py-12 px-4">
              <MessageSquare size={28} className="mx-auto text-slate-600 mb-3" />
              <p className="text-sm text-slate-500">
                {search ? 'No chats found' : 'No conversations yet'}
              </p>
              {!search && (
                <p className="text-xs text-slate-600 mt-1">Start a new chat above</p>
              )}
            </div>
          ) : (
            <div className="space-y-1">
              {filtered.map((conv) => (
                <div
                  key={conv.id}
                  onClick={() => onSelect(conv.id)}
                  className={`
                    group flex items-center gap-2.5 rounded-lg px-3 py-2.5 cursor-pointer
                    transition-all
                    ${activeId === conv.id
                      ? 'bg-indigo-500/15 border border-indigo-400/25'
                      : 'hover:bg-white/5 border border-transparent'}
                  `}
                >
                  <MessageSquare
                    size={15}
                    className={activeId === conv.id ? 'text-cyan-400' : 'text-slate-500'}
                  />
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm truncate ${activeId === conv.id ? 'text-slate-100' : 'text-slate-300'}`}>
                      {conv.title}
                    </p>
                    <p className="text-[10px] text-slate-500 mt-0.5">
                      {formatRelative(conv.updatedAt)}
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDelete(conv.id);
                    }}
                    className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-red-400 transition-all p-1"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-indigo-500/10">
          <div className="glass rounded-xl px-3 py-2.5 flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-cyan-500 to-indigo-600 flex items-center justify-center text-white text-xs font-bold">
              U
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-slate-200 truncate">Owner</p>
              <p className="text-[10px] text-slate-500">Local mode</p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
