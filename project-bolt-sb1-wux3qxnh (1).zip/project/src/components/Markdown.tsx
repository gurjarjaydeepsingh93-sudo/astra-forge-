import { useMemo } from 'react';

/**
 * Lightweight markdown renderer — handles headings, bold, italic,
 * inline code, code blocks, lists, blockquotes, and paragraphs.
 * No external dependencies. Returns React nodes.
 */
function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function renderInline(text: string): React.ReactNode[] {
  const nodes: React.ReactNode[] = [];
  let remaining = text;
  let key = 0;

  const patterns: { regex: RegExp; render: (m: RegExpMatchArray) => React.ReactNode }[] = [
    {
      regex: /^\*\*(.+?)\*\*/,
      render: (m) => <strong key={key++} className="font-semibold text-white">{m[1]}</strong>,
    },
    {
      regex: /^\*(.+?)\*/,
      render: (m) => <em key={key++} className="italic">{m[1]}</em>,
    },
    {
      regex: /^`(.+?)`/,
      render: (m) => (
        <code key={key++} className="px-1.5 py-0.5 rounded-md bg-cyan-500/15 text-cyan-300 text-[0.85em] font-mono">
          {m[1]}
        </code>
      ),
    },
    {
      regex: /^\[(.+?)\]\((.+?)\)/,
      render: (m) => (
        <a key={key++} href={m[2]} target="_blank" rel="noopener noreferrer" className="text-cyan-400 underline hover:text-cyan-300">
          {m[1]}
        </a>
      ),
    },
  ];

  while (remaining.length > 0) {
    let matched = false;
    for (const p of patterns) {
      const m = remaining.match(p.regex);
      if (m) {
        nodes.push(p.render(m));
        remaining = remaining.slice(m[0].length);
        matched = true;
        break;
      }
    }
    if (!matched) {
      // Take next char as text, group consecutive non-special chars
      const nextSpecial = remaining.search(/(\*\*|\*|`|\[)/);
      if (nextSpecial === -1) {
        nodes.push(<span key={key++}>{remaining}</span>);
        remaining = '';
      } else if (nextSpecial === 0) {
        nodes.push(<span key={key++}>{remaining[0]}</span>);
        remaining = remaining.slice(1);
      } else {
        nodes.push(<span key={key++}>{remaining.slice(0, nextSpecial)}</span>);
        remaining = remaining.slice(nextSpecial);
      }
    }
  }

  return nodes;
}

export function Markdown({ content }: { content: string }) {
  const blocks = useMemo(() => {
    const lines = content.split('\n');
    const result: React.ReactNode[] = [];
    let i = 0;
    let key = 0;

    while (i < lines.length) {
      const line = lines[i];

      // Code block
      if (line.trim().startsWith('```')) {
        const lang = line.trim().slice(3).trim();
        const codeLines: string[] = [];
        i++;
        while (i < lines.length && !lines[i].trim().startsWith('```')) {
          codeLines.push(lines[i]);
          i++;
        }
        i++; // skip closing ```
        result.push(
          <div key={key++} className="my-3 rounded-xl overflow-hidden border border-indigo-500/20">
            {lang && (
              <div className="px-4 py-2 text-[11px] font-mono text-slate-400 bg-slate-900/60 border-b border-indigo-500/15">
                {lang}
              </div>
            )}
            <pre className="px-4 py-3 overflow-x-auto bg-slate-950/70 text-sm leading-relaxed">
              <code className="font-mono text-cyan-200">{escapeHtml(codeLines.join('\n'))}</code>
            </pre>
          </div>
        );
        continue;
      }

      // Headings
      const headingMatch = line.match(/^(#{1,4})\s+(.*)/);
      if (headingMatch) {
        const level = headingMatch[1].length;
        const text = headingMatch[2];
        const sizes = ['text-xl', 'text-lg', 'text-base', 'text-sm'];
        result.push(
          <div key={key++} className={`${sizes[level - 1] || 'text-sm'} font-bold text-white mt-4 mb-2`}>
            {renderInline(text)}
          </div>
        );
        i++;
        continue;
      }

      // Blockquote
      if (line.trim().startsWith('>')) {
        const quoteLines: string[] = [];
        while (i < lines.length && lines[i].trim().startsWith('>')) {
          quoteLines.push(lines[i].trim().slice(1).trim());
          i++;
        }
        result.push(
          <blockquote key={key++} className="my-3 pl-4 border-l-2 border-cyan-400/40 text-slate-400 italic">
            {renderInline(quoteLines.join(' '))}
          </blockquote>
        );
        continue;
      }

      // Ordered list
      if (/^\d+\.\s+/.test(line.trim())) {
        const items: string[] = [];
        while (i < lines.length && /^\d+\.\s+/.test(lines[i].trim())) {
          items.push(lines[i].trim().replace(/^\d+\.\s+/, ''));
          i++;
        }
        result.push(
          <ol key={key++} className="my-2 space-y-1.5 pl-5 list-decimal list-outside marker:text-cyan-400">
            {items.map((item, idx) => (
              <li key={idx} className="text-slate-300 leading-relaxed">{renderInline(item)}</li>
            ))}
          </ol>
        );
        continue;
      }

      // Unordered list
      if (/^[-*]\s+/.test(line.trim())) {
        const items: string[] = [];
        while (i < lines.length && /^[-*]\s+/.test(lines[i].trim())) {
          items.push(lines[i].trim().replace(/^[-*]\s+/, ''));
          i++;
        }
        result.push(
          <ul key={key++} className="my-2 space-y-1.5 pl-5 list-disc list-outside marker:text-cyan-400">
            {items.map((item, idx) => (
              <li key={idx} className="text-slate-300 leading-relaxed">{renderInline(item)}</li>
            ))}
          </ul>
        );
        continue;
      }

      // Horizontal rule
      if (line.trim() === '---' || line.trim() === '***') {
        result.push(<hr key={key++} className="my-4 border-indigo-500/15" />);
        i++;
        continue;
      }

      // Empty line
      if (line.trim() === '') {
        i++;
        continue;
      }

      // Paragraph — gather consecutive non-empty, non-special lines
      const paraLines: string[] = [];
      while (
        i < lines.length &&
        lines[i].trim() !== '' &&
        !lines[i].trim().startsWith('```') &&
        !lines[i].trim().startsWith('#') &&
        !lines[i].trim().startsWith('>') &&
        !/^\d+\.\s+/.test(lines[i].trim()) &&
        !/^[-*]\s+/.test(lines[i].trim()) &&
        lines[i].trim() !== '---' &&
        lines[i].trim() !== '***'
      ) {
        paraLines.push(lines[i]);
        i++;
      }
      if (paraLines.length > 0) {
        result.push(
          <p key={key++} className="my-2 leading-relaxed text-slate-300">
            {renderInline(paraLines.join(' '))}
          </p>
        );
      }
    }

    return result;
  }, [content]);

  return <div className="text-sm">{blocks}</div>;
}
