export function AstraLogo({ size = 36 }: { size?: number }) {
  return (
    <div
      className="relative flex items-center justify-center rounded-xl"
      style={{ width: size, height: size }}
    >
      <svg width={size} height={size} viewBox="0 0 48 48" fill="none">
        <defs>
          <linearGradient id="astraGrad" x1="0" y1="0" x2="48" y2="48">
            <stop offset="0%" stopColor="#22d3ee" />
            <stop offset="50%" stopColor="#818cf8" />
            <stop offset="100%" stopColor="#c084fc" />
          </linearGradient>
        </defs>
        <path
          d="M24 4 L42 38 L24 28 L6 38 Z"
          fill="url(#astraGrad)"
          opacity="0.9"
        />
        <circle cx="24" cy="20" r="4" fill="#22d3ee" />
        <circle cx="24" cy="20" r="4" fill="none" stroke="#818cf8" strokeWidth="0.5" opacity="0.6" />
      </svg>
    </div>
  );
}
