import type { Conversation, AIModel } from './types';

const CONV_KEY = 'astra-conversations';
const ACTIVE_KEY = 'astra-active-conversation';
const MODEL_KEY = 'astra-active-model';

export const MODELS: AIModel[] = [
  { id: 'astra-4', name: 'ASTRA 4', description: 'Most capable — best for complex tasks', badge: 'Flagship' },
  { id: 'astra-4-mini', name: 'ASTRA 4 Mini', description: 'Faster, lighter — great for everyday chat', badge: 'Fast' },
  { id: 'astra-3', name: 'ASTRA 3', description: 'Previous generation — solid all-rounder', badge: 'Legacy' },
  { id: 'astra-reason', name: 'ASTRA Reason', description: 'Deep step-by-step reasoning mode', badge: 'Think' },
];

export function getStoredModel(): string {
  try {
    return localStorage.getItem(MODEL_KEY) || MODELS[0].id;
  } catch {
    return MODELS[0].id;
  }
}

export function setStoredModel(model: string) {
  try { localStorage.setItem(MODEL_KEY, model); } catch { /* ignore */ }
}

export function loadConversations(): Conversation[] {
  try {
    const raw = localStorage.getItem(CONV_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch { /* ignore */ }
  return [];
}

export function saveConversations(conversations: Conversation[]) {
  try {
    localStorage.setItem(CONV_KEY, JSON.stringify(conversations));
  } catch { /* ignore */ }
}

export function getActiveId(): string | null {
  try {
    return localStorage.getItem(ACTIVE_KEY);
  } catch {
    return null;
  }
}

export function setActiveId(id: string | null) {
  try {
    if (id) localStorage.setItem(ACTIVE_KEY, id);
    else localStorage.removeItem(ACTIVE_KEY);
  } catch { /* ignore */ }
}

export function getModelName(id: string): string {
  return MODELS.find((m) => m.id === id)?.name || id;
}
