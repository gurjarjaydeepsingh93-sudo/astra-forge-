import type { Message } from './types';

/**
 * Local response engine — works with zero configuration.
 * When a real AI provider is connected later, swap this for an API call.
 */
export function generateResponse(userText: string, history: Message[]): string {
  const text = userText.toLowerCase().trim();
  if (!text) return "I didn't catch that — could you say that again?";

  const greetings = ['hello', 'hi', 'hey', 'greetings', 'yo', 'sup', 'howdy'];
  if (greetings.some((g) => text === g || text.startsWith(g + ' '))) {
    return [
      "Hey there! I'm **ASTRA**, your AI assistant.",
      "",
      "I can help you with:",
      "",
      "- Answering questions and explaining concepts",
      "- Brainstorming ideas and creative content",
      "- Writing, editing, and proofreading",
      "- Coding and technical problems",
      "- Planning projects and breaking down tasks",
      "- Just chatting about whatever's on your mind",
      "",
      "What can I help you with today?",
    ].join('\n');
  }

  if (text.includes('how are you') || text.includes('how do you feel')) {
    return "I'm running at full capacity — every system is operational and ready to go. Thanks for asking! What can I help you with?";
  }

  if (text.includes('your name') || text.includes('who are you') || text.includes('what are you')) {
    return "I'm **ASTRA** — a personal AI assistant designed to help with research, writing, coding, brainstorming, project planning, and just about anything you'd like to explore. Think of me as your all-purpose thinking partner.";
  }

  if (text.includes('thank')) {
    return "You're very welcome! I'm always here when you need me. Is there anything else I can help with?";
  }

  if (text.includes('bye') || text.includes('goodbye') || text.includes('see you') || text.includes('later')) {
    return "Until next time! I'll be right here whenever you need me. Take care.";
  }

  if (text.startsWith('help') || text.includes('what can you do') || text.includes('what do you do')) {
    return [
      "Here's what I can help with:",
      "",
      "1. **Answer questions** — explain concepts, break down ideas, give overviews",
      "2. **Brainstorm** — generate ideas, explore options, think creatively",
      "3. **Write & edit** — drafts, emails, essays, stories, scripts",
      "4. **Code** — explain code, debug issues, suggest approaches, write snippets",
      "5. **Plan** — project breakdowns, task lists, step-by-step guides",
      "6. **Analyze** — compare options, weigh pros and cons, summarize",
      "7. **Chat** — conversation, opinions, discussion",
      "",
      "Just type whatever you need and I'll dive in.",
    ].join('\n');
  }

  // Coding
  if (text.includes('code') || text.includes('program') || text.includes('function') || text.includes('bug') || text.includes('error') || text.includes('javascript') || text.includes('python') || text.includes('react') || text.includes('typescript')) {
    const trimmed = userText.trim();
    return [
      "Here's my approach to your coding question:",
      "",
      'Looking at "' + trimmed + '" — I can help you work through this. Let me break it down:',
      "",
      "**Key considerations:**",
      "",
      "1. Understand the problem and expected inputs/outputs",
      "2. Identify edge cases and constraints",
      "3. Write clean, readable code with proper types",
      "4. Test with realistic data",
      "",
      "```typescript",
      "// Example scaffold",
      "function solve(input: string): string {",
      "  // Step 1: validate input",
      "  if (!input) throw new Error('Input required');",
      "",
      "  // Step 2: process",
      "  const result = input.trim().toLowerCase();",
      "",
      "  // Step 3: return",
      "  return result;",
      "}",
      "```",
      "",
      "This is running in **local mode** without a connected AI provider, so this is a scaffolded response. Connect a real provider to get fully contextual code assistance. Would you like me to elaborate on any part?",
    ].join('\n');
  }

  // Writing
  if (text.includes('write') || text.includes('essay') || text.includes('story') || text.includes('poem') || text.includes('email') || text.includes('article') || text.includes('blog')) {
    const trimmed = userText.trim();
    return [
      "I'd love to help with writing! Here's a draft based on \"" + trimmed + "\":",
      "",
      "---",
      "",
      "The art of communication lies not just in what we say, but in how we shape our words to resonate with those who hear them. Every great piece of writing begins with a single idea — a spark that ignites the imagination and compels the reader to journey alongside the writer.",
      "",
      "---",
      "",
      "This is a **local demo response**. I'm running in offline mode, so this is a template rather than a fully tailored piece. Connect an AI provider for personalized, high-quality writing that adapts to your tone, audience, and goals.",
      "",
      "Would you like me to adjust the tone, length, or style?",
    ].join('\n');
  }

  // Questions
  if (text.includes('?') || text.startsWith('what') || text.startsWith('how') || text.startsWith('why') || text.startsWith('when') || text.startsWith('where') || text.startsWith('who') || text.startsWith('can you') || text.startsWith('could you') || text.startsWith('is ') || text.startsWith('are ') || text.startsWith('should')) {
    const trimmed = userText.trim();
    return [
      'Great question! Let me share my thoughts on **"' + trimmed + '"**.',
      "",
      "Here's how I'd break it down:",
      "",
      "1. **Context** — This is an interesting topic that has multiple angles to consider.",
      "2. **Key points** — There are a few important factors at play here, each worth examining.",
      "3. **My take** — Based on the information available, I'd approach this by considering both the immediate implications and the broader picture.",
      "",
      "> **Note:** I'm currently running in **local mode** without a connected AI provider. This means I can give you structured, conversational responses but not fully researched, context-aware answers. To unlock my full capabilities, connect an AI provider like OpenAI or Anthropic in settings.",
      "",
      "Would you like me to go deeper on any of these points?",
    ].join('\n');
  }

  // Use conversation context if available
  const lastAssistant = [...history].reverse().find((m) => m.role === 'assistant');
  if (lastAssistant) {
    const trimmed = userText.trim();
    return [
      'Building on our conversation — you mentioned "' + trimmed + '". Here\'s how I\'d continue:',
      "",
      "1. We can take this in several directions depending on your goal",
      "2. I can help you explore each option in more detail",
      "3. Just let me know which path interests you most",
      "",
      "What would you like to explore next?",
    ].join('\n');
  }

  // Default
  const trimmed = userText.trim();
  const responses = [
    [
      'I hear you — "' + trimmed + '". That\'s an interesting topic. Let me share a few thoughts:',
      "",
      "1. There's often more than one way to look at this",
      "2. The best approach depends on your specific goals",
      "3. I can help you explore any angle you'd like",
      "",
      "What's most important to you here?",
    ].join('\n'),
    [
      'Got it — "' + trimmed + '". Here\'s my perspective:',
      "",
      "This is something I can help you think through step by step. Whether you're looking for a quick answer or a deep dive, I'm ready to go whichever direction you need.",
      "",
      "What would be most useful — a broad overview or a specific detail?",
    ].join('\n'),
    [
      'Interesting — "' + trimmed + '". Let me engage with that:',
      "",
      "1. I can help you break this down into manageable parts",
      "2. We can explore different approaches and trade-offs",
      "3. I'll help you arrive at a clear conclusion",
      "",
      "Where should we start?",
    ].join('\n'),
  ];
  return responses[Math.floor(Math.random() * responses.length)];
}

export function generateTitle(firstMessage: string): string {
  const words = firstMessage.trim().split(/\s+/).slice(0, 6).join(' ');
  return words.length > 0 ? words : 'New Chat';
}
